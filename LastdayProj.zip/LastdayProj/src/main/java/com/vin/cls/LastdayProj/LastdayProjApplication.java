package com.vin.cls.LastdayProj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LastdayProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(LastdayProjApplication.class, args);
	}

}
