package com.vin.cls.LastdayProj;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Books {
	@Id
	private int bid;
	private String bname;
	private String bauth;
	private String bpubs;

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getBauth() {
		return bauth;
	}

	public void setBauth(String bauth) {
		this.bauth = bauth;
	}

	public String getBpubs() {
		return bpubs;
	}

	public void setBpubs(String bpubs) {
		this.bpubs = bpubs;
	}

}
