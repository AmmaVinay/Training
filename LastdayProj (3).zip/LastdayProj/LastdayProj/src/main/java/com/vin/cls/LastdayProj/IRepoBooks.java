package com.vin.cls.LastdayProj;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface IRepoBooks extends JpaRepository<Books, Integer> {
	@Query(value = "select * from public.\"Book\"", nativeQuery = true)
	List<Books> lsRegs();

	@Query(value = "INSERT INTO public.\"Book\" (bid, bname, bauth, bpubs) VALUES (:bid, :bname, :bauth, :bpubs)", nativeQuery = true)
	void inReg(@Param("bid") int bid, @Param("bname") String bname, @Param("bauth") String bauth,
			@Param("bpubs") String bpubs);

	@Query(value = "insert into public.\"Book\" (bid, bname, bauth, bpubs) values (:bid, :bname, :bauth, :bpubs)", nativeQuery = true)
	void insReg(@Param("bid") int bid, @Param("bname") String bname, @Param("bauth") String bauth,
			@Param("bpubs") String bpubs);

	@Query(value = "update public.\"Book\" set bname=:bname, bauth=:bauth where bid=:bid", nativeQuery = true)
	void upsReg(@Param("bid") int bid, @Param("bname") String bname, @Param("bauth") String bauth);

	@Query(value = "delete from public.\"Book\" where bid=:bid", nativeQuery = true)
	void delReg(@Param("bid") int bid);

 
 }
