package com.vin.cls.LastdayProj;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IRepoRegister extends JpaRepository<Register, Integer> {

    @Query(value = "select * from public.\"Register\"", nativeQuery = true)
    List<Register> lsRegs();

    @Query(value = "INSERT INTO public.\"Register\" (id, name, email) VALUES (:rid, :rname, :remail)", nativeQuery = true)
    void inReg(@Param("rid") int rid, @Param("rname") String rname, @Param("remail") String remail);
    
	@Query(value="insert into public.\"Register\" values (:rid,:rname,:remail)",nativeQuery=true)
	void insReg(@Param("rid") int rid,@Param("rname") String rname,@Param("remail") String remail);
	
	@Query(value="update public.\"Register\" set rname=:rname,remail=:remail where rid=:rid",nativeQuery=true)
	void upsReg(@Param("rid") int rid,@Param("rname") String rname,@Param("remail") String remail);
	
	@Query(value="delete from public.\"Register\" where rid=:rid",nativeQuery = true)
	void delReg(@Param("rid") int rid);

}
