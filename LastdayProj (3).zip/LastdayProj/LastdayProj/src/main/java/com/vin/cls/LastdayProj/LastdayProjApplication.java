package com.vin.cls.LastdayProj;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LastdayProjApplication implements CommandLineRunner {
	// @Autowired
	// private IRepoRegister repor;

	@Autowired 
	private IRepoBooks brepo;

	public static void main(String[] args) {
		SpringApplication.run(LastdayProjApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// repor.lsRegs().stream().forEach(n -> System.out.println(n.getRid() + " " +
		// n.getRname() + " " + n.getRemail()));
		// repor.inReg(13, "Baby", "baby@gmail.com");
		// repor.upsReg(1, "NPCI", "npci@org.in.com");
		// repor.upsReg(13, "MyBaby", "baby@gmail.com");
		brepo.lsRegs().stream().forEach(n -> System.out.println(n.getBid() + " " + n.getBname() + " " + n.getBauth() + " " + n.getBpubs()));
		brepo.insReg(2, "Home", "Amma", "Vinay");
	}
}
