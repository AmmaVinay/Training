package com.vin.cls.LastdayProj;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RepoTesterService {
	@Autowired
	private IRepoBooks bRepo;
	@GetMapping
	public List<Books>retBooks(){
		return bRepo.lsRegs();
	}
	@GetMapping("ibooks/{bid}")
	public String insBooks(@PathVariable("bid") int bid,@PathVariable("bname") String bname,@PathVariable("bauth") String bauth,@PathVariable("bpubs") String bpubs) {
		bRepo.insReg(bid, bname, bauth, bpubs);
//		bRepo.upsBook(bid, bname, bauth, bpubs);
//		bRepo.delBook(11);
		return "Completed";
	}
}

