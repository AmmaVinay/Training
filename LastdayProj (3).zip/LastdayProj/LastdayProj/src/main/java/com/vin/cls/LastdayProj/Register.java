package com.vin.cls.LastdayProj;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Register {
	@Id
	private int rid;
	private String rname;
	private String remail;

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public String getRemail() {
		return remail;
	}

	public void setRemail(String remail) {
		this.remail = remail;
	}

}
