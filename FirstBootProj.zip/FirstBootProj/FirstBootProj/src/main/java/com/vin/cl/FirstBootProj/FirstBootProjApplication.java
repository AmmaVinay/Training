package com.vin.cl.FirstBootProj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstBootProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstBootProjApplication.class, args);
	}

}
