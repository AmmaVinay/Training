package com.sat.d;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MnCls implements IFaceConsts {
public static void main(String[] args) throws IOException {
//	String fname="sqrtfile.txt";
//	String op="";
//	FileInputStream fis=new FileInputStream(IFaceConsts.paths + fname);
//	int y=0;
//	while((y=fis.read())!=-1) {
//		op+=(char)y;
//	}
//	System.out.println(op);
//	fis.close();
	String fname="sqrtfile.txt";
	wfile(fname);
}
	
	public static void wFile(String fname) throws IOException {
		String fin="";
		for (int i = 0; i < 1000; i++) {
			fin+="Sqrt("+i+")="+Math.sqrt(i)+"\n";
		}
		File f=new File(IFaceConsts.paths+fname);
		try {
			FileOutputStream fos= new FileOutputStream(f);
			fos.write(fin.getBytes());
			fos.flush();
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done Writing the File");
	}
	
	
//	public static void main(String[] args) {
//		String dname= "MyDirTest";
//		String dnamea="MyDirVinayFolder";
//		File f = new File(paths+dname);
//		f.mkdir();
////		f.renameTo(new File(paths+dnamea));
////		f.delete();
//
//		File ff=new File("C:delhiofficefiles\\");
//		String[] arr = ff.list();
//		for(String j:arr) {
////			if(j.indexOf(".txt")>0) {
////				System.out.println(j);
////			}
//		}
//		
//		
//		
////		String myfile="Tester.txt";
////		File file=new File(paths+myfile);
////		try {
////			file.createNewFile();
////		} catch (IOException e) {
////			e.printStackTrace();
////		}
//
//	}

}
