package com.sat.d;

public interface IFaceConsts  {
	static final String paths="C:\\Users\\NPCIFile\\";

}
