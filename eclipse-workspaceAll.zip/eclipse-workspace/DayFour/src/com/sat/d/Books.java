package com.sat.d;

public class Books {
	@MyAnnoMethod(descMeth = "My Class")
	public String retDets() {
		return "This is Class Describing Library";
	}
	@MyAnnoMethod(descMeth = "My Book")
	public String retBooksFirst() {
		return "This is my First Book";
		
	}
}
