package com.sat.d;

import java.lang.reflect.Field;

public class MNCLsA {
	public static void main(String[] args) {
//		BankAccount ba = new BankAccount();
//		MyAnoClass ma = ba.getClass().getAnnotation(MyAnoClass.class);
//		System.out.println(ma.retDesc());
//		System.out.println(ma.retPrio());
		
		Person p = new Person();
		for(Field field:p.getClass().getDeclaredFields()) {
			MyFiledAnno af=(MyFiledAnno)field.getAnnotation(MyFiledAnno.class);
			String finString = String.format("field: %s\n Annotation value:%s \n",field.getName(), af.descField());
			System.out.println(finString);
		}
	}
}
