package com.sat.d;

import java.lang.reflect.Method;

public class MnClsB {
	public static void main(String[] args) {
		Books b = new Books();
		for(Method m:b.getClass().getDeclaredMethods()) {
			MyAnnoMethod am=(MyAnnoMethod)m.getAnnotation(MyAnnoMethod.class);
			System.out.println(am.descMeth());
			String fin=String.format("Name of the Method:%s\nAnnotation of the Method:%s\n", m.getName(),am.descMeth());
			System.out.println(fin);
		}
	}
}
