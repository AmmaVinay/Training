package com.sat.d;

public class Person {
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPemail() {
		return pemail;
	}
	public void setPemail(String pemail) {
		this.pemail = pemail;
	}
	public String getPmobile() {
		return pmobile;
	}
	public void setPmobile(String pmobile) {
		this.pmobile = pmobile;
	}
	@MyFiledAnno(descField = "Govt IF of the Person")
	private int pid;
	@MyFiledAnno(descField = "Name of the Person")
	private String pname;
	@MyFiledAnno(descField = "Email of the Person")
	private String pemail;
	@MyFiledAnno(descField = "Person of the Person")
	private String pmobile;
	
}
