package com.sat.d;

public class ThreadMain {
	public static void main(String[] args) {
		MyThread thra = new MyThread();
		thra.start();
		MyThreadA thrb = new MyThreadA();
		thrb.run();
		System.out.println("**********Starting the Program");
		Thread aa = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("Insude Thread");
				
			}
		});
		aa.start();
		new Runnable() {
			@Override
			public void run() {
				System.out.println("Another Thread Insude Main");
			}
		}.run();
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("Runs Inside Void Main Another Thred!");
			}
		}).start();
	}
}
