package com.sat.d;

@MyAnoClass(retDesc = "Bank Account Class");
public class BankAccount {
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getAhname() {
		return ahname;
	}
	public void setAhname(String ahname) {
		this.ahname = ahname;
	}
	public int bid;
	private String bname;
	private String ahname;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.ahname+" "+this.bid+" "+this.bname;
	}
}
