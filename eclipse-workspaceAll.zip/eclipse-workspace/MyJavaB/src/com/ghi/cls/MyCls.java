package com.ghi.cls;

public class MyCls {

	public static void main(String[] args) {
		String str = "This is a test string";
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		System.out.println(str.substring(0,7));
		System.out.println(str.charAt(6));
		System.out.println(str.concat(" Vinay"));
		StringBuffer stb = new StringBuffer();
		stb.append(str);
		for(int i=0; i<24; i++) {
			stb.append((char)(i+94));
		}
		System.out.println(stb.toString());
		
		
		StringBuilder build = new StringBuilder();
		build.append(str.toUpperCase());
		
		for(int i=0; i<24; i++) {
			build.append((char)(i+94));
		}
		System.out.println(build.toString());
        
		String a = "65";
		System.out.println(Integer.parseInt(a));
		System.out.println(String.valueOf('a').toUpperCase());
		
		MyClass.tester();
		for (int i = 0; i < 10; i++) {
			MyClass mcl = new MyClass();
			mcl.testerA();
		}
		

	}

}
