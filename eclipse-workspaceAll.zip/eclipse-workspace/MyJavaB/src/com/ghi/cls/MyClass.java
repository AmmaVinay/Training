package com.ghi.cls;

import java.util.StringTokenizer;

//////////////

public class MyClass {

	public static void main(String[] args) {
		MyClass myClass = new MyClass();
		String u = myClass.retSqrts();
//		System.out.println(u);
//		String[] sArr=u.split(";");
//		for(String a:sArr) {
//			System.out.println(a);
//		}

		StringTokenizer stk = new StringTokenizer(u, ";");
//		while(stk.hasMoreTokens()) {//Iterator
//			System.out.println(stk.nextToken());
//		}

		while (stk.hasMoreElements()) {
			String ua = String.valueOf(stk.nextElement());
			System.out.println(ua);
		}

	}

	private static void firstMeth() {
		String str = "This is a test string for testing";
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		System.out.println(str.substring(0, 7));
		System.out.println(str.charAt(6));
		System.out.println(str.concat(" Satish string"));
		StringBuffer stb = new StringBuffer();
		stb.append(str);
		for (int i = 0; i < 24; i++) {
			stb.append((char) (i + 94));
		}
		System.out.println(stb.toString());
		StringBuilder build = new StringBuilder();
		build.append(str.toUpperCase());
		for (int i = 2; i < 29; i++) {
			build.append((char) (i + 94));
		}
		System.out.println(build.toString());
		System.out.println(String.valueOf('a').toUpperCase());
		String aa = "99";
		System.out.println(Integer.parseInt(aa));
		MyClass.tester();
		for (int i = 0; i < 10; i++) {
			MyClass mcl = new MyClass();
			mcl.testrA();
		}
	}
}
////////

/***
 * This is a utility class to understand the concepts of static block and static
 * variables, Delimiters
 * 
 * @author Satish
 *
 */
public class MyClass {
	final static int UPS = 1001;

	/**
	 * This is the only final method of the class
	 * 
	 * @author Satish
	 */
	public final void MyMethA() {
		System.out.println("Cant change me");
	}

	private static final int a = 1000;
	static {
		System.out.println("This is a static block" + a);
	}

	public MyClass() {
		System.out.println("This is c0nstructor");
	}

	/***
	 * This is the static method of the class
	 */
	public static void tester() {
		System.out.println("this isa test method from other class");
	}

	/***
	 * This is a non static method for testing
	 */
	public void testrA() {
		System.out.println("This is non static");
	}

	/***
	 * This method returns the square roots of 1000 numbers as a semi colon
	 * delimited string
	 * 
	 * @return String
	 * @author Satish
	 */
	public String retSqrts() {
		String fin = "";
		for (int i = 1; i < UPS; i++) {
			fin += "Sqrt(" + i + ")=" + Math.sqrt(i) + ";";
		}
		return fin;
	}

	/***
	 * Method to return the natural logs of 1000 numbers
	 * 
	 * @return String of logs
	 * @author Satish
	 */
	public String retLogs() {
		String fin = "";
		for (int i = 1; i < UPS; i++) {
			fin += "Log(" + i + ")=" + Math.log(i) + ":";
		}
		return fin;
	}

	public double retSumRoots(int a, int b) {
		return Math.hypot(a, b);
	}

	public double retSumRoots(double a, double b) {
		double ans = 0.0;
		ans = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
		return ans;
	}

	public double retrAreaTriangel(double a, double b) {
		return (0.5 * a) * b;
	}

}
