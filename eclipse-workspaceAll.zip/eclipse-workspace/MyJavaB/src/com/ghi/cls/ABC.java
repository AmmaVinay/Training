package com.ghi.cls;

public class ABC {
	double[] arr1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	double[] arr2 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

	prnArea(arr1,arr2);

	public double retSumRoots(double a, double b) {

	}
}
