package com.abc.cls;

public class DCls extends CCls {
	public DCls() {
		System.out.println("CD's Constructor");
	}
}
