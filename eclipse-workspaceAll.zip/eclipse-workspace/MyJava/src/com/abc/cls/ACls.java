package com.abc.cls;

public class ACls {
	public ACls() {
		System.out.println("A's Constructor");
	}
}
