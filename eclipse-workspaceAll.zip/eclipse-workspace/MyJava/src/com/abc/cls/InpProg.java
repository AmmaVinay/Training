package com.abc.cls;

import java.util.Arrays;
import java.util.Scanner;

public class InpProg {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Student[] sArr = new Student[5];
        int i = 0;
        while (i < 5) {
            System.out.println("Enter ID ");
            int id = Integer.parseInt(scan.nextLine());
            System.out.println("Enter your Class");
            String Cls = scan.nextLine();
            System.out.println("Enter your Name");
            String name = scan.nextLine();

            Student std = new Student();
            std.setsID(id);
            std.setsClass(Cls);
            std.setsName(name);
            
            sArr[i] = std;
            System.out.println(std);  
            i++;
        }
        System.out.println(Arrays.deepToString(sArr));

//         for (Student a : sArr) {
//            System.out.println(a);   
//        }
    }
}
