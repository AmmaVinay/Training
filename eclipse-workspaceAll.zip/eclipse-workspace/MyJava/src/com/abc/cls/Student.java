package com.abc.cls;

public class Student {
	private int sID;
	private String sName;
	private String sClass;
	public int getsID() {
		return sID;
	}
	public void setsID(int sID) {
		this.sID = sID;
	}
	public String getsName(String sName) {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsClass() {
		return sClass;
	}
	public void setsClass(String sClass) {
		this.sClass = sClass;
	}
@Override
public String toString() {
	// TODO Auto-generated method stub
	String fin = String.format("Name:%s\nClass:%s\nId", this.sName, this.sID, this.sClass);
	return fin ;
	}
	
}
