package com.abc.cls;

public class BasChil extends BasCls {

	@Override
	public void menthEE() {
		// TODO Auto-generated method stub

	}

}
