package com.abc.cls;

 public class GranPar {

	public void methA() {
		System.out.println("Iam from grand parent");
	}
}
