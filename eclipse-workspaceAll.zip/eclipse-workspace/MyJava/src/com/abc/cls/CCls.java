package com.abc.cls;

public class CCls extends BCls {
	public CCls() {
		// TODO Auto-generated constructor stub
		System.out.println("BC's Constructor");
	}
}
