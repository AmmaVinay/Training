package com.abc.cls;
import java.util.Scanner;
public class Quest {

	public static void main(String[] args) {
		System.out.println("Enter You Name: ");
		String name="";
		Scanner scan=new Scanner(System.in);
		name=scan.nextLine();
		System.out.println("My Name is "+name);
	}

}
