package com.abc.cls;

public interface IFaceA {
	public void menthAA();
	public void menthBB();

}
