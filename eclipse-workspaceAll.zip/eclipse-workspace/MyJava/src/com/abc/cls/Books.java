package com.abc.cls;


public class Books {
	private String bname;
	private String bauth;
	
	public Books() {
		// TODO Auto-generated constructor stub
	}
	
	public Books(String a,String b) {
		this.bname=a;
		this.bauth=b;
		System.out.println(this.bname+" "+this.bauth);
	}
}
