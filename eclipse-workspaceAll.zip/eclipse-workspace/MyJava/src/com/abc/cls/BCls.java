package com.abc.cls;

public class BCls extends ACls {
public BCls() {
	System.out.println("AB's Constructor");

}
}
