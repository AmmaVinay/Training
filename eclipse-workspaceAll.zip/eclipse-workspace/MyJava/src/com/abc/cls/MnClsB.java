package com.abc.cls;

public class MnClsB {
	public static void main(String[] args) {
		int[] arr1=new int[4];
		arr1[0]=123;
		arr1[1]=456;
		arr1[2]=789;
		arr1[3]=10112;
		
		for(int i=0; i<arr1.length; i++) {
			System.out.println(arr1[i]);
		}
		
		int i=0;
		while(i<3) {
			System.out.println(arr1[i]);
			i++;
		}
		
		int j=0;
		do {
			System.out.println(arr1[j]);
			j++;
		}while(j<3);

		
		float[] arr = {1f, 2f, 3f};
		for(int z=0; z<arr.length; z++) {
			System.out.println(arr1[z]);
		}
		
		//Boolean Array;
		
 		boolean[] bool = {true, false, true, true};
        
		for(int a = 0; a < bool.length; a++ ) {
		    String anBool = (a == 2) ? "Hi" : "Hello";
		    System.out.println(anBool);
		}


	}
}
