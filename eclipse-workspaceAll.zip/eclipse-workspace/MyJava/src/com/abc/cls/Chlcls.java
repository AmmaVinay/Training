package com.abc.cls;

public class Chlcls extends GranPar {
	public void methB() {
		System.out.println("hello Ho w are you");
	}

	
}
