package com.abc.cls;

public interface IFaceB {
	public void methodCC();
	public void methodDD();

}
