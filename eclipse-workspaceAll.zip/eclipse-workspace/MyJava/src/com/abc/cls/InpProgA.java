package com.abc.cls;

import java.util.Arrays;
import java.util.Scanner;
public class InpProgA {

	public static void main(String[] args) {
		Employee[] eArr=new Employee[2];
		Scanner scan = new Scanner(System.in);
		for(int i=0; i<5; i++) {
			System.out.println("Enter Your ID");
			int id=Integer.parseInt(scan.nextLine());
			
			System.out.println("Enter your Name");
			String na=scan.nextLine();
			
			System.out.println("Enter your Desigination");
			String des=scan.nextLine();
			
			System.out.println("Enter Your Salary");
			int sal=Integer.parseInt(scan.nextLine());
			
			Employee e = new Employee(id, na, des, sal);
 			eArr[i]=e;
		}
		// TODO Auto-generated method stub
		
		String u=Arrays.deepToString(eArr);
		System.out.println();

	}

}
