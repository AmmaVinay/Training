package com.abc.cls;

public abstract class BasCls {
	public abstract void menthEE();
	public void menthFF() {
		System.out.println("This is an Abstract Menthod");
	}
}
