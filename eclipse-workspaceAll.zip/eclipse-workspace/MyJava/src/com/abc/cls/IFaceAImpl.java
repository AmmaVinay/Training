package com.abc.cls;

public class IFaceAImpl implements IFaceA, IFaceB {
	public void menthAA() {
		System.out.println("This is my First Implement");
	}
	
	public void menthBB() {
		System.out.println("This is my Second Implement");
	}

	@Override
	public void methodCC() {
		System.out.println("This is my Third Implement");
		
	}

	@Override
	public void methodDD() {
		System.out.println("This is my Fourth Implement");
		    
	}
}
