package com.abc.cls;

public class GrasChl  extends Chlcls{

}
