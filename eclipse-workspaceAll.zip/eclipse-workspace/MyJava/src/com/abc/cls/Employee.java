package com.abc.cls;

public class Employee {
	private int eid;
	private String ename;
	private String edesing;
	private int sal;
	
	public Employee() {
		
	}
	
	public Employee(int a, String b, String c, int d) {
		this.eid=a;
		this.ename=b;
		this.edesing=c;
		this.sal=d;
	}
	public String toString() {
		return this.eid+" "+this.ename+" "+this.edesing+" "+this.sal;
	}
}
