package com.abc.cls;


public class Mncls {

	public static void main(String[] args) {
		System.out.println("Refernce Types"); 
		Person pObj=new Person();
		pObj.setPid(10);
		pObj.setPname("Vinay");
		pObj.setPemail("ammavinay@gmail.com");
		System.out.println("Id: "+ pObj.getPid()+"\n" + "Name :" + pObj.getPname()+"\n" + "Mail: " + pObj.getPemail());

		Books n=new Books("Adventures of tom sawyer","Mark Twain");
		GrasChl gch=new GrasChl();
		gch.methB();
		gch.methB();
		
		IFaceAImpl impl = new IFaceAImpl();
		impl.menthAA();
		impl.menthBB();
		impl.methodCC();
		impl.methodDD();
		
		BasChil abs = new BasChil();
		abs.menthEE();
		abs.menthFF();
		
		DCls d = new DCls();
		
		Student std = new Student();
 		std.setsName("Vinay");
 		std.setsClass("BTech");
 		std.setsID(0);
	}

}
