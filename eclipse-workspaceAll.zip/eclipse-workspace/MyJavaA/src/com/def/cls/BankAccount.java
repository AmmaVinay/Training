package com.def.cls;
 

public class BankAccount {
    private String bankId;
    private String bankType;
    private int accountId;  
    // Default constructor
    private BankAccount() {
    }

    // Constructor with three parameters
    public BankAccount(String bankId, String bankType, int accountId) {
        this.bankId = bankId;
        this.bankType = bankType;
        this.accountId = accountId;
    }

	@Override
	public String toString() {
		return this.bankId + " " + this.bankType + " " + this.accountId;
	}
		
}
