package com.def.cls;

import java.util.Arrays;

public class BankCls {
    private String bankId;
    private String bankName;
    private BankAccount[] bActs; // Array to hold BankAccount objects

    // Default constructor
    public BankCls() {
    }

    // Constructor with three parameters: bankId, bankName, and an array of BankAccounts
    public BankCls(String bankId, String bankName, BankAccount[] bActs) {
        this.bankId = bankId;
        this.bankName = bankName;
        this.bActs = bActs;
        // For demonstration, printing the bank and associated accounts
        System.out.println("Bank: " + this.bankId + " " + this.bankName);
        System.out.println("Bank Accounts: " + Arrays.toString(this.bActs));
    }

    @Override
    public String toString() {
        return "BankCls [bankId=" + bankId + ", bankName=" + bankName + ", bankAccounts=" + Arrays.toString(bActs) + "]";
    }
}
