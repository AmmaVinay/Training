package com.def.cls;

public class Student {
	private int subId;
	private String subName;
	private Subjects sub;

 	public int getSubId() {
		return subId;
	}


	public void setSubId(int subId) {
		this.subId = subId;
	}


	public String getSubName() {
		return subName;
	}


	public void setSubName(String subName) {
		this.subName = subName;
	}


	public Subjects getSub() {
		return sub;
	}


	public void setSub(Subjects sub) {
		this.sub = sub;
	}


	
	
	public String toString() {
		return this.subId+" "+this.subName+" " + this.sub.getSubId() + " " + this.sub.getSubName();
	}

	
}
