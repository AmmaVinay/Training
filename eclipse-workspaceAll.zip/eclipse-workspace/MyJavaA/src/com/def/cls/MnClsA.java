package com.def.cls;

public class MnClsA {

	public static void main(String[] args) {
		Student[] stArr =  new Student[5];
		int[] arr1 = {11,12,13,14,15};
		String[] arr2 = {"Maths","Physics","Chemistry","History", "Biology"};
		String[] arr3 = {"Vinay","Dinesh", "Sandeep", "Vamshi", "Pavan"};
		
		for( int i=0; i< arr3.length; i++) {
			
			Subjects sub=new Subjects();
			sub.setSubId(arr1[i]);
			sub.setSubName(arr2[i]);
			
			Student std = new Student();
			std.setSubId(arr1[i]);
			std.setSubName(arr3[i]);   
			std.setSub(sub);			
			stArr[i] = std;
			
		}
		for(Student a: stArr) {
			System.out.println(a);
		}
	}

}
