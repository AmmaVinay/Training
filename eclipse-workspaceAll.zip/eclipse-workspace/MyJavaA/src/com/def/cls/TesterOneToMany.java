package com.def.cls;

public class TesterOneToMany {
    public static void main(String[] args) {
        int[] arr1 = {111, 222, 333, 444, 555}; // Account IDs
        String[] arr2 = {"ICICI", "HDFC", "SBI", "UBN", "HSBC"}; // Bank Names
        String[] arr3 = {"A1234H", "B4567H", "H34678V", "F97853G", "H3462HL"}; // Bank IDs

         BankAccount[] accounts = new BankAccount[arr1.length];

         for (int i = 0; i < arr3.length; i++) {
            accounts[i] = new BankAccount(arr3[i], arr2[i], arr1[i]); // Creating BankAccount with three parameters
        }

         for (int i = 0; i < arr2.length; i++) {
            BankCls bank = new BankCls(arr3[i], arr2[i], accounts); // Create BankCls with the array of BankAccount
        }
    }
}
