package com.cls.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MnClsB {
	public static void main(String[] args) {
		List<Employee> ls = new ArrayList<>();
		List<Person> lsp = new ArrayList<Person>();
		List<Player> player =  new ArrayList<Player>();
		int[] arr1 = { 12, 34, 56, 78 };
		String[] arr2 = { "Vinay", "Ankitha", "Avinash", "Chakri" };
		int[] arr3 = { 4,2,1,3 };
		String[] arr4 = { "AP", "TS", "MP", "GOA" };
		for (int i = 0; i < arr4.length; i++) {
//			Employee emp = new Employee(arr1[i],arr2[i],arr3[i]);
//			ls.add(emp);
//			Person per = new Person(arr1[i], arr2[i], arr3[i]);
//			lsp.add(per);
			Player play = new Player(arr1[i], arr2[i], arr3[i], arr4[i]);
			player.add(play);
			
		}
//		ls.sort(new Comparator<Employee>() {
//
//			@Override
//			public int compare(Employee o1, Employee o2) {
//				// TODO Auto-generated method stub
//				return o1.getEsal()-o2.getEsal();
//			}
//			
//		});
//		Collections.sort(lsp);
		Collections.sort(player);
		System.out.println(player);
//		System.out.println(lsp);
	}
}
