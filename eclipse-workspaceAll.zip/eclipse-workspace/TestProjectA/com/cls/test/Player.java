package com.cls.test;

public class Player implements Comparable<Player> {
    public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getRank() {
		return rank;
	}


	public void setRank(int rank) {
		this.rank = rank;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}

	private int id;
    private String name;
    private int rank;
    private String state;

    public Player(int id, String name, int rank, String state) {
        this.id = id;
        this.name = name;
        this.rank = rank;
        this.state = state;
    }

 
    @Override
    public int compareTo(Player other) {
        // Sorting by rank in ascending order
        return Integer.compare(this.rank, other.rank);
    }

    @Override
    public String toString() {
        // Enhanced toString method for better readability
        return id + " " + name + " " + rank + " " + state;
    }
}
