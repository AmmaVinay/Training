package com.cls.test;

public class Employee {
	public Employee(int esal, String eemail, String ename) {
		super();
		this.ename = ename;
		this.eemail = eemail;
		this.esal = esal;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEemail() {
		return eemail;
	}
	public void setEemail(String eemail) {
		this.eemail = eemail;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
	public String ename;
	public String eemail;
	public int esal;
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.eemail+" "+this.ename+" "+this.esal;
	}
}
