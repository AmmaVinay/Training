package com.cls.test;

public class MnClsA {

}
