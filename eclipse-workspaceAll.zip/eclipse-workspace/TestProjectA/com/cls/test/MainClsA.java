package com.cls.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainClsA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> ls = new ArrayList();
		int[] arr1 = {12,34,56,78};
		String[] arr2 = {"Vinay", "Ankitha", "Avinash", "Chakri"};
		String[] arr3 = {"Vinay@gmail.com", "Ankitha@gmail.com", "Avinash@gmail.com", "Chakri@gmail.com"};
		
		for (int i = 0; i < arr3.length; i++) {
			Student std = new Student();
			std.setSid(arr1[i]);
			std.setSname(arr2[i]);
			std.setSemail(arr3[i]);
			ls.add(std);
			
		}
		System.out.println(ls);
		System.out.println("**************************");
		System.out.println("After Sorting");
		
		StudentSorter sor = new StudentSorter();
		Collections.sort(ls,sor);
		System.out.println(ls);
	}

}
