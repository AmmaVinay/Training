package com.cls.test;

public class Person implements Comparable<Person> {
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Person(int id, String email, String name) {
		super();
		this.name = name;
		this.email = email;
		this.id = id;
	}

	public String name;
	public String email;
	public int id;
	
	@Override
	public int compareTo(Person o) {
		// TODO Auto-generated method stub
		if(this.id==o.id) {
			return 0;
		}else if(this.id>o.id) {
			return 1;
		}else {
			return -1;
		}
		
		
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.id + " " + this.name + " " + this.email;
	}

	
	
}
