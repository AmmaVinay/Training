package com.cls.test;

import java.util.Comparator;

public class StudentSorter implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		// TODO Auto-generated method stub
		return o1.getSid()-o2.getSid();
	}

}
