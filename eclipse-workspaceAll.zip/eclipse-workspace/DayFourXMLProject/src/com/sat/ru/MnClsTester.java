package com.sat.ru;

import com.sat.model.BMarshall;

public class MnClsTester {

	public static void main(String[] args) {
		BMarshall bml = new BMarshall();
		bml.retXmlBook();
	}

}
