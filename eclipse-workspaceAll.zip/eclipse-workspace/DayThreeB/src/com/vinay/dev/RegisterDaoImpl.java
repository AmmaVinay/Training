package com.vinay.dev;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.vinay.inte.IRegisterDao;
import com.vinay.mods.Register;

public class RegisterDaoImpl implements IRegisterDao {

	static Properties props=null;
	static Connection conn=null;
	static {
		try {
			FileReader reader=new FileReader(new File("C:\\Users\\Satish\\WorkSpaceEveningClass\\DSCodeProjC\\src\\app.properties"));
			props=new Properties();
			props.load(reader);
			Class.forName(props.getProperty("drivername"));
			conn=DriverManager.getConnection(props.getProperty("conn"), props.getProperty("username"), props.getProperty("password"));
		} catch (IOException | ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public List<Register> retRegs() {
		String query="select * from "+props.getProperty("tabaname");
		List<Register> lr=new ArrayList<>();
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Register r=new com.vinay.mods.Register(rs.getInt(1), rs.getString(2), rs.getString(3));
				lr.add(r);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lr;
	}

	@Override
	public Register retReg(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String insReg(Register r) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String upReg(Register r) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String delReg(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
