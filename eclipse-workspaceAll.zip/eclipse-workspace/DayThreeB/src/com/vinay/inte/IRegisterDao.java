package com.vinay.inte;
import java.util.List;

import com.vinay.mods.Register;

public interface IRegisterDao {
	public List<Register> retRegs();
	public Register retReg(int id);
	public String insReg(Register r);
	public String upReg(Register r);
	public String delReg(int id);

}


 