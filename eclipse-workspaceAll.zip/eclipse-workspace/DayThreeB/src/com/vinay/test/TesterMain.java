package com.vinay.test;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import com.vinay.dev.RegisterDaoImpl;
import com.vinay.mods.Register;

public class TesterMain {
    public static void main(String[] args) {
    	
    	
    	RegisterDaoImpl imp = new RegisterDaoImpl();
    	List<Register> lr = imp.retRegs();
    	for(Register r:lr) {
    		System.out.println(r);
    	}
    	imp.retReg(5);
    }
        public static void testmain() {
            try {
                // Correct file path syntax
                FileReader reader = new FileReader("C:\\Users\\localadmin\\eclipse-workspace\\DayThreeB\\src\\app.properties");

                // Create Properties object and load the file
                Properties props = new Properties();
                props.load(reader);
                
                // Access and print the properties
                System.out.println(props.getProperty("drivername"));
                System.out.println(props.getProperty("conn"));
                System.out.println(props.getProperty("username"));
                System.out.println(props.getProperty("password"));
                System.out.println(props.getProperty("tabname"));
                
                // Close the reader
                reader.close();

            } catch (IOException e) {
                e.printStackTrace(); // Correct method name
            }

    	}
    }
}
