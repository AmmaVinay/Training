package com.list.cls;

import java.util.ArrayList;
import java.util.Arrays;

public class MainCls {

	public static void main(String[] args) {
		// Create an ArrayList of String to store names of countries. Add 5 countries to
		// the list and display the list.

		ArrayList<Integer> arrList = new ArrayList<>();
//		String[] country = {"INDIA","AMERICA", "AUSTRAILA", "CANADA","CUBA"};
//        ArrayList<String> arrList = new ArrayList<>(Arrays.asList("INDIA","AMERICA", "AUSTRAILA", "CANADA","CUBA"));
		int[] country = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		for (int a : country) {
			arrList.add(a);

		}
		System.out.println(arrList);
		int thirdElement = arrList.get(3);

		System.out.println(arrList.set(5, 15));

		System.out.println(arrList);
		int removeElement = arrList.remove(3);
		System.out.println(removeElement);
		arrList.sort(null);
		System.out.println(arrList);
		System.out.println(arrList.size() - 1);

	}

}
