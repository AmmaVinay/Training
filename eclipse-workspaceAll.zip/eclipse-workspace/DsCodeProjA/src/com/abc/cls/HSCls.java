package com.abc.cls;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class HSCls {

	public static void main(String[] args) {
		HashMap<Integer, String> hs = new HashMap<>();
		int[] arr1 = { 1, 2, 3, 4, 5 };
		String[] arr2 = { "Telugu", "Hindi", "English", "Maths", "Physics" };
		for (int i = 0; i < arr2.length; i++) {
			hs.put(arr1[i], arr2[i]);
		}
		System.out.println(hs);
		System.out.println("**************");

		List arr = Arrays.asList(hs.entrySet());
		for (Object a : arr) {
			
			System.out.println(a);
		}

		System.out.println("**************");
		
		Iterator itr=hs.entrySet().iterator();
		while(itr.hasNext()) {
//			hs.put(6, "Science");
			System.out.println(itr.next());
		}
		System.out.println("************************");
		Iterator itra=hs.keySet().iterator();
		while(itra.hasNext()) {
			Object key=itra.next();
			System.out.println(key+" "+hs.get(key));
		}
		System.out.println("************************");
		Iterator itrb=Arrays.asList(hs.entrySet()).iterator();
		while(itrb.hasNext()) {
			System.out.println(itrb.next());
		}

	}

}
