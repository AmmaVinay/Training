package com.abc.cls;


import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class LHSCls {
	public static void main(String[] args) {
		int[] arr1 = { 1, 2, 3, 4, 5 };
		String[] arr2 = { "Telugu", "Hindi", "English", "Maths", "Physics" };
		LinkedHashMap<Integer, String> lhs =  new LinkedHashMap<Integer, String>();
		for (int i = 0; i < arr2.length; i++) {
			lhs.put(arr1[i], arr2[i]);
		}
		System.out.println(lhs);
		
		Iterator itr=lhs.entrySet().iterator();
		while(itr.hasNext()) {
			Entry ent=(Entry)itr.next();
			System.out.println(ent);
		}

	}
}
