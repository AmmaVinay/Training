package com.abc.cls;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.TreeMap;
 
public class TMCls {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer, String> tm= new TreeMap<Integer, String>();
		int[] arr1 = { 1, 2, 3, 4, 5 };
		String[] arr2 = { "Telugu", "Hindi", "English", "Maths", "Physics" };
		
		for (int i = 0; i < arr2.length; i++) {
			tm.put(arr1[i], arr2[i]);
		}
		System.out.println(tm);
		
		Iterator itr=tm.entrySet().iterator();
		while(itr.hasNext()) {
			Entry ent=(Entry)itr.next();
			System.out.println(ent);
		}
		

	}

}
