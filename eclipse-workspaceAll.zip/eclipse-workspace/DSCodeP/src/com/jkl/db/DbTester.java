package com.jkl.db;

import java.util.Iterator;
import java.util.List;

/***
 * Entry Point to test the CRUID Methods

 */
public class DbTester {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DbUtilsCls db = new DbUtilsCls();
		List<Register> lr = db.retRegs();
		Iterator<Register> itr = lr.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
