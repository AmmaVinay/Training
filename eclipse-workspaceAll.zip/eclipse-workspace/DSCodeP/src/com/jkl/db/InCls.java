package com.jkl.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InCls {
	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection conn=DriverManager.getConnection("jdbc:postgresql://localhost:5432/ClassDB", "postgres", "root");
			PreparedStatement ps=conn.prepareStatement("insert into public.\"Register\" values (11,'NPCI','npci@org.in')");
			ps.execute();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
