package com.jkl.db;

public class Register {
	
	/***
	 * Poojo class
	 */
	public Register() {
	}

	public Register(int a, String b, String c) {
		this.rid = a;
		this.rname = b;
		this.remail = c;
	}

	private int rid;

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	public String getRemail() {
		return remail;
	}

	public void setRemail(String remail) {
		this.remail = remail;
	}

	private String rname;
	private String remail;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.rid + " " + this.remail + " " + this.rname;
	}

}