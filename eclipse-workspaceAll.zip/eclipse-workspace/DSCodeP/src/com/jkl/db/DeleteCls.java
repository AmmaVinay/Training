package com.jkl.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteCls {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the row no to delete");
		int y=scan.nextInt();
		Class.forName("org.postgresql.Driver");
		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ClassDB", "postgres","root");
	    String query="delete from public.\"Register\" where rid=?";
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setInt(1, y);
		ps.executeUpdate();
	}
}
