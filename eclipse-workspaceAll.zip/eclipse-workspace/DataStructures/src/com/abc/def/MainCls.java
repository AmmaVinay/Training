package com.abc.def;

public class MainCls {
	public static void main(String[] args) {
		BasCls ba = new BasCls() {
			
			@Override
			public String retRev(String a) {
				return (new StringBuffer(a)).reverse().toString();
				
			}
		};
		ba.retA();
		ba.retB();
		String u = ba.retRev("AmmA Vinay");
		System.out.println(u);

		IFaceB faceb = new IFaceB() {

			@Override
			public String retRvStr(String a) {
				// TODO Auto-generated method stub
				return a.toUpperCase();
			}
	

			@Override
			public String retUpStr(String a) {
				// TODO Auto-generated method stub
				return (new StringBuffer(a)).reverse().toString();
			}
			
		};
		System.out.println();
		
	}
	public static void main() {
		
		IFaceA facea = new IFaceA() {

			@Override
			public void methA() {
				// TODO Auto-generated method stub
				System.out.println("Method A ");
				
			}

			@Override
			public void methB() {
				// TODO Auto-generated method stub
				System.out.println("Method B");

			}

			@Override
			public void methC() {
				// TODO Auto-generated method stub
				System.out.println("Method C ");

			}
			
		};
	}
}
