package com.abc.def;

public interface IFaceA {
	public void methA();
	public void methB();
	public void methC();

}
