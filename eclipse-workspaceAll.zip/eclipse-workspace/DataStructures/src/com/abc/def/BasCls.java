package com.abc.def;

public abstract class BasCls {
	public abstract String retRev(String a);
	public void retA() {
		System.out.println("Non Abstract Class");
	}
	public void retB() {
		System.out.println("Second Non Abstract Method");
	}

}
