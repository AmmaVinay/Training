package com.abc.def;

import java.util.Hashtable;

public class MnClsHTab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr1 = { 1, 2, 3, 4, 5 };
		String[] arr2 = { "Telugu", "Hindi", "English", "Maths", "Science" };
		Hashtable<Integer, String> ht = new Hashtable<>();
		for (int i = 0; i < arr2.length; i++) {
			ht.put(arr1[i], arr2[i]);
		}
		System.out.println(ht);

	}

}
