package com.abc.def;

public interface IFaceB {
	public String retRvStr(String a);
	public String retUpStr(String a);
	


}
