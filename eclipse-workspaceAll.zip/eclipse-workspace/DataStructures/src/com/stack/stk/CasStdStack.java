package com.stack.stk;

import java.util.Scanner;
import java.util.Stack;

public class CasStdStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the String that need to be reversed");
		String j = "This string os going to be reversed";
		j=scan.nextLine();
		char[] arr=j.toCharArray();
		
		Stack stk = new Stack();
		for(char c:arr) {
			stk.push(c);
		}
		while(!(stk.isEmpty())) {
			System.out.print(stk.pop());
		}

	}

}
