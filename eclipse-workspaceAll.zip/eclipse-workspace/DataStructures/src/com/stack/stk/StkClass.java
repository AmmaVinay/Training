package com.stack.stk;
import java.util.Stack;
public class StkClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack sta=new Stack();
		String[] arr= {"Vinay", "Krishna", "Pavan", "Ankitha", "Avinash"};
		for(String j:arr) {
			sta.push(j);
		}
		while(!(sta.isEmpty())) {
			System.out.println(sta.pop());
		}

	}

}
