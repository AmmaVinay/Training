package com.sat.hsset;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Stack;
import java.util.TreeSet;

public class ClsMainHS {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String ans="I am an Employee in an Organisation";
		Stack sta = new Stack();
		char[] arr =  ans.toCharArray();
		Arrays.asList(arra)
		
		
	}

		
	public static void mentA() {
//		int[] arr = {11,22,33,55,6,7,7,9,0,0,8,5,3,22,33,22};
		char[] arr = {'a','b','c','a','b','c', 'A'};
		TreeSet set = new TreeSet();
		for(char a:arr) {
			int j=a;
			set.add(j);
		}
		System.out.println(set);
	}
	
	
	private static void hslhsMeth() {
		// TODO Auto-generated method stub
//		int[] arr = {1,2,3,4,5,5,5,6,6,6,6,2,2,3,3,4,4,5,6,};
//		char[] arr = {'a','a','b','d','a','a','b','d','a','a','b','d'};
//		String[] arr = {"Vinay", "Vinay", "Ankitha", "Ankitha"};
//		LinkedHashSet  lhs = new  LinkedHashSet();
		HashSet hs =new HashSet();
		for(String i:arr) {
			hs.add(i);
		}
		System.out.println(hs);

	}

}
