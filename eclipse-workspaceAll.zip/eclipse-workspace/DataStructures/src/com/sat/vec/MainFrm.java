package com.sat.vec;

import java.awt.Container;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JFrame;

public class MainFrm extends JFrame {

	public static void main(String[] args) {
		public MainFrm() {
		Container const = getContentPane();
           Vector vec = new  Vector();
           for (i=0; i<100; i++) {
			vec.add("Log(i+1)=" + Math.log(i));		
		}
           JComboBox box = new JComboBox(vec);
           cont.add(box);
		}

	}

}
