package com.sat.vec;

import java.util.Arrays;
import java.util.Vector;

public class VecClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector vec=new Vector();
		for(int i=0; i<1000; i++) {
			String j="Sqrt("+(i+1)+")="+Math.sqrt(i+1);
			vec.add(j);
		}
		//System.out.println(Arrays.deepToString(vec.toArray()));
		int i=vec.size();
		int j=0;
		while(j<i) {
			System.out.println(vec.toArray()[j]);
			j++;
		}
	}
	}
	


