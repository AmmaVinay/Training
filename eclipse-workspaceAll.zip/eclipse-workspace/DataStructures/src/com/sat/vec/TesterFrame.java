package com.sat.vec;

import java.awt.FlowLayout;

public class TesterFrame {

 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainFrm frm = new MainFrm();
		frm.setDefaultCloseOperation(2);
		frm.setVisible(true);
		frm.setLayout(new FlowLayout());
		frm.setSize(500,300);

	}

}
