package com.sat.linl;

import java.util.LinkedList;

public class ClsMainLL {

	public static void main(String[] args) {
		LinkedListString();

//		LinkedList<Integer> ll=new LinkedList<Integer>();
//		LinkedList<Float> ll=new LinkedList<Float>();
		LinkedList<Double> ll = new LinkedList<Double>();
		for (int i = 0; i < 1000; i++) {
//			ll.add((float) ((i+1)+0.5));
			ll.add((double) ((i + 1) + 0.55555));
		}
		System.out.println(ll);
		LinkedList<Character> llc = new LinkedList<Character>();
		llc.add('a');
		llc.add('b');
		llc.add('c');
		System.out.println(llc);
		LinkedList<Boolean> llb = new LinkedList<Boolean>();
		llb.add(true);
		llb.add(true);
		llb.add(true);
		llb.add(false);
		llb.add(false);
		System.out.println(llb);

	}

	private static void LinkedListString() {
		// TODO Auto-generated method stub
		LinkedList<String> ll = new LinkedList();
		String arr[] = { "Vinay", "Ankitha", "Avinash", "Krishna" };
		for (String j : arr) {
//			ll.addFirst(j); //Stack
//			ll.addLast(j); //Queue
			ll.add(j);
		}
		// System.out.println(ll);
		for (String j : ll) {
			System.out.println(j);
		}
		System.out.println("**************");
		int i = 0;
		while (i < ll.size()) {
			System.out.println(ll.get(i));
			i++;
		}
	}

}
