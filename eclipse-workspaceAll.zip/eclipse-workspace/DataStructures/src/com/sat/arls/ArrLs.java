package com.sat.arls;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrLs {

	public ArrLs() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList al = new ArrayList();
		for(int i=0; i<1000; i++) {
			al.add("String"+i+1);	
		}
		System.out.println(Arrays.deepToString(al.toArray()));

	}

}
