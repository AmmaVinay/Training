package com.sat.arls;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrAppCas {

	public ArrAppCas() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList al = new ArrayList();
		Scanner scan = new Scanner(System.in);
		String ans = "y";
		while (ans.equalsIgnoreCase("y")) {
			System.out.println("Enter a String to add to array list ");
			String a = scan.nextLine();
			al.add(a);
			System.out.println("Enter y to continue to the input");
			ans = scan.nextLine();
		}
		System.out.println("********************");
		System.out.println("\t\t\tNow The Output");
		for (Object a : al) {
			System.out.println(a);
		}
		System.out.println("********************");

	}

	private static Object toUpperCase() {
		// TODO Auto-generated method stub
		return null;
	}

}
