package com.cls.test;

public class MnCls {

}
