/**
 * 
 */
/**
 * 
 */
module DayFourC {
	requires java.sql;
	requires jackson.all;
}