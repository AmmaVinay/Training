package com.sat.cl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;

 
public class RJsonizer {
	static Connection conn=null;
	static {
		try {
			Class.forName("org.postgresql.Driver");
			conn=DriverManager.getConnection("jdbc:postgresql://localhost:5432/ClassDB", "postgres", "root");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	
	private List<Register> retList(){
		List<Register> lr=new ArrayList<Register>();
		try {
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery("select * from public.\"Register\"");
			while(rs.next()) {
				Register r=new Register(rs.getInt(1), rs.getString(2), rs.getString(3));
				lr.add(r);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lr;
	}
	
	public String retJsonObj() {
		String jsn="";
		ObjectMapper om=new ObjectMapper();
		try {
			jsn=om.writeValueAsString(retList());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsn;
	}

}
