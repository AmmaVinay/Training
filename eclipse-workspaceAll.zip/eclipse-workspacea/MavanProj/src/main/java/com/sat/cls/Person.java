package com.sat.cls;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name ="person")
public class Person implements Serializable {
	public Person(int pid, String pname, String pemail) {
		this.pid = pid;
		this.pname = pname;
		this.pemail = pemail;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPemail() {
		return pemail;
	}

	public void setPemail(String pemail) {
		this.pemail = pemail;
	}

	private int pid;
	private String pname;
	private String pemail;

 	public Person() {
	}
	
	
}
