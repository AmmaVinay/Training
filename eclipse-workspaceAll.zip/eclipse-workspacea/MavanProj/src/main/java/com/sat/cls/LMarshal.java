package com.sat.cls;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

public class LMarshal {
	 public static void main(String[] args)  {
		try {
			String path="C:\\Users\\NPCIFile\\my\\laptop.xml";
			JAXBContext context = JAXBContext.newInstance(Laptops.class);
			Marshaller mar=context.createMarshaller();
			int[] arr1= {1,2,3,4,5};
			String[] arr2 = {"Inspiron", "Opera" ,"Latitute", "Yoga"};
			String[] arr3 = {"HP", "DELL", "Mac", "Lenovo"};
			
			List<Laptops> lap = new ArrayList<Laptops>();
			Laptops l =  new Laptops();
			l.setManid(arr1[0]);
			l.setLname(arr2[0]);
			l.setLbrand(arr3[0]);
			mar.marshal(l, new File(path));
			System.out.println("Done Writing");
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
