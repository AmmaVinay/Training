package com.sat.cls;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;


public class BMarshall {
	/***
	 * Method which serializes java to XML
	 * 
	 * @return
	 */
	public void retXmlBook() {
		JAXBContext context = null;
		try {
			context = JAXBContext.newInstance(Books.class);
			Marshaller marshal = context.createMarshaller();
			Books b = new Books(212, "Quiet sigh of morre", "Amma Vinay");
			marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshal.marshal(b, System.out);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
