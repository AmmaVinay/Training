package com.sat.cls;

public class MainCls {

	public static void main(String[] args) {
//		BMarshall bml = new BMarshall();
//		bml.retXmlBook();
		PMarshall pml = new PMarshall();
		pml.retXmlPerson();
		
	}

}
