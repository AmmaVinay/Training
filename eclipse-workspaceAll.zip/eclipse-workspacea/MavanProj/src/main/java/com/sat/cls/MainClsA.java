package com.sat.cls;

import java.io.StringReader;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;

public class MainClsA {

	public static void main(String[] args) throws JAXBException {
		// TODO Auto-generated method stub
		String xml = "<person>\r\n" + "    <pemail>Amma Vinay</pemail>\r\n" + "    <pid>100</pid>\r\n"
				+ "    <pname>Ammavinay@gmail.com</pname>\r\n" + "</person>";
		JAXBContext content = JAXBContext.newInstance(Person.class);
		Unmarshaller unm = content.createUnmarshaller();
		Person p = (Person) unm.unmarshal(new StringReader(xml));
		System.out.println(p.getPid() + " " + p.getPname() + " " + p.getPemail());

	}

}
