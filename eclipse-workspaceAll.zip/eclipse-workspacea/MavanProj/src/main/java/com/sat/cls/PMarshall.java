package com.sat.cls;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

public class PMarshall {
	public void retXmlPerson() {
		JAXBContext context = null;
		try {
			context = JAXBContext.newInstance(Person.class);
			Marshaller marshal = context.createMarshaller();
			Person b = new Person(100, "Ammavinay@gmail.com", "Amma Vinay");
			marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshal.marshal(b, System.out);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
