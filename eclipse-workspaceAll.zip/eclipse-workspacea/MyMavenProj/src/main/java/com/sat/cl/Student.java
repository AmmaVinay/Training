package com.sat.cl;

public class Student {
	private String sname;
	private String sbranch;

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSbranch() {
		return sbranch;
	}

	public void setSbranch(String sbranch) {
		this.sbranch = sbranch;
	}

	@Override
	public String toString() {
		return "Student [sname=" + sname + ", sbranch=" + sbranch + "]";
	}

}
