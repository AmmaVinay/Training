package com.sat.cl;

public class Employee extends Person {
	public String geteOrg() {
		return eOrg;
	}

	public void seteOrg(String eOrg) {
		this.eOrg = eOrg;
	}

	private String eOrg;
	
}
