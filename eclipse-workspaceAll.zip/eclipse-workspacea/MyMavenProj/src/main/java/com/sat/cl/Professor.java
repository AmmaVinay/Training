package com.sat.cl;

public class Professor {
	private String pname;
	private String pbranch;

	public Professor() {

	}

	public Professor(String pname, String pbranch) {
		super();
		this.pname = pname;
		this.pbranch = pbranch;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPbranch() {
		return pbranch;
	}

	public void setPbranch(String pbranch) {
		this.pbranch = pbranch;
	}

	@Override
	public String toString() {
		return "Professor [pname=" + pname + ", pbranch=" + pbranch + "]";
	}

}
