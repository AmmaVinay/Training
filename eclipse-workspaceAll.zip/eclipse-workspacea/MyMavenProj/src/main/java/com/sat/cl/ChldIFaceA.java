package com.sat.cl;

public class ChldIFaceA implements IFaceA {

	@Override
	public String retStra() {
		// TODO Auto-generated method stub
		return "Testing For Child";
	}

	@Override
	public double retDou() {
		// TODO Auto-generated method stub
		return Math.PI;
	}

}
