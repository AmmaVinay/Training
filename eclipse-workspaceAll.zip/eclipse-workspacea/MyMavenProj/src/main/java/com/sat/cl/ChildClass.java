package com.sat.cl;

public class ChildClass extends BaseClass {

	@Override
	public String retRoot(int a) {
		// TODO Auto-generated method stub
		return "Root is " + Math.sqrt(a);
	}

}
