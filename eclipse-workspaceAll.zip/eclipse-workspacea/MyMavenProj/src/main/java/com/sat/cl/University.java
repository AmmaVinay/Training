package com.sat.cl;

public class University {
	private String uName;
	private Student[] sList;

	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public Student[] getsList() {
		return sList;
	}
	public void setsList(Student[] sList) {
		this.sList = sList;
	}
 
}
