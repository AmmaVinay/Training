package com.sat.cl;

import java.util.Arrays;
import java.util.function.Consumer;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MnCls {

	public static void main(String[] args) {
		ApplicationContext cont = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Books b = (Books) cont.getBean("booka");
		System.out.println(b.getId() + " " + b.getBname() + " " + b.getBauth());

		BankAccount ba = (BankAccount) cont.getBean("bact");
		System.out.println(ba.toString());

		LedgerBook ledgehome = (LedgerBook) cont.getBean("ledgehome");
		System.out.println(ledgehome);

		Employee emp = (Employee) cont.getBean("chldbean");
		System.out.println(emp.getPid() + " " + emp.getPname() + " " + emp.getPemail() + " " + emp.geteOrg());

		TempEmployee tempemp = (TempEmployee) cont.getBean("tempchld");
		System.out.println(tempemp.getTempName());

		ChildClass bas = (ChildClass) cont.getBean("chldbase");
		System.out.println(bas.retRoot(10));

		System.out.println(bas.getEmailId() + " " + bas.getMobile());

		ChldIFaceA ch = (ChldIFaceA) cont.getBean("chldifacea");
		System.out.println(ch.retDou());
		System.out.println(ch.retStr("Vinay"));
		System.out.println(ch.retStra());

		University uni = (University) cont.getBean("univ");
		System.out.println(uni.getuName());
		System.out.println(uni.getsList());
		Arrays.asList(uni.getsList()).stream().forEach(new Consumer<Student>() {

			@Override
			public void accept(Student t) {
				// TODO Auto-generated method stub
				System.out.println(t);

			}
		});
	}
}
