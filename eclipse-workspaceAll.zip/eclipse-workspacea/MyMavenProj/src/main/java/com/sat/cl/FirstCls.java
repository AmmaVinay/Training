package com.sat.cl;

import java.util.Map;

public class FirstCls {
	private String idenString;
	private Map<Integer, String> myMap;

	public String getIdenString() {
		return idenString;
	}

	public void setIdenString(String idenString) {
		this.idenString = idenString;
	}

	public Map<Integer, String> getMyMap() {
		return myMap;
	}

	public void setMyMap(Map<Integer, String> myMap) {
		this.myMap = myMap;
	}

}
