package com.sat.cl;

public interface IFaceA {
	default String retStr(String a) {
		return a.toUpperCase();
	}
	public String retStra();
	public double retDou();
}
