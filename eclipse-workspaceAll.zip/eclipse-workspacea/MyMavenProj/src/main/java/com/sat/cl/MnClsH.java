package com.sat.cl;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Consumer;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MnClsH {

	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		FirstCls cls = (FirstCls) ac.getBean("firstCls");
		System.out.println(cls.getIdenString());
		Map<Integer, String> map = cls.getMyMap();
//		Iterator itr = map.entrySet().iterator();
//		while (itr.hasNext()) {
//			Entry<Integer, String> ent = (Entry) itr.next();
//			System.out.println("Key :" + " " + ent.getKey() + " " + "Value: "+ ent.getValue());
//		}
		map.entrySet().iterator().forEachRemaining(new Consumer<Entry<Integer, String>>() {

			@Override
			public void accept(Entry<Integer, String> t) {
				// TODO Auto-generated method stub
				System.out.println("Key :" + " " + t.getKey() + " " + "Value: "+ t.getValue());
			
			}
		});	}

}
