package com.sat.cl;

public class TempEmployee extends Employee {
	public String getTempName() {
		return tempName;
	}

	public void setTempName(String tempName) {
		this.tempName = tempName;
	}

	private String tempName;
	
}
