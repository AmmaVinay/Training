package com.sat.cl;

import java.util.function.Consumer;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ListTester {
	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Department dept = (Department) ac.getBean("DeptA");
		System.out.println(dept.getDeptId() + " " + dept.getDeptName());
		dept.getlProfs().stream().forEach(new Consumer<Professor>() {

			@Override
			public void accept(Professor t) {
				System.out.println(t);

			}
		});
	}

}
