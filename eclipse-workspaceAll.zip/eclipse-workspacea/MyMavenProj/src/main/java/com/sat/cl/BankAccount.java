package com.sat.cl;

public class BankAccount {

	private String bankId;
	private String bankName;
	private String actName;

	public BankAccount() {

	}

	public BankAccount(String bankId, String bankName, String actName) {
		this.bankId = bankId;
		this.bankName = bankName;
		this.actName = actName;
	}

	@Override
	public String toString() {
		return "BankAccount [bankId=" + bankId + ", bankName=" + bankName + ", actName=" + actName + "]";
	}

}
