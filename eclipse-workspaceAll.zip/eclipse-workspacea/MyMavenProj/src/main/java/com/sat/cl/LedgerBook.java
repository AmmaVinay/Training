package com.sat.cl;

public class LedgerBook {
	private int leId;
	private String leCat;
	private String leItem;
	private int quantity;

	public int getLeId() {
		return leId;
	}
	public void setLeId(int leId) {
		this.leId = leId;
	}
	public String getLeCat() {
		return leCat;
	}
	public void setLeCat(String leCat) {
		this.leCat = leCat;
	}
	public LedgerBook() {
	}
	public LedgerBook(String item,int quantity) {
		this.leItem=item;
		this.quantity=quantity;
	}
	@Override
	public String toString() {
		return "LedgerBook [leId=" + leId + ", leItem=" + leItem + ", quantity=" + quantity + ", leCat=" + leCat
				+ "]";
	}
}
