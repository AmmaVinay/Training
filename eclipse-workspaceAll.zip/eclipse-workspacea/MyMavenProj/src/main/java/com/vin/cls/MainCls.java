package com.vin.cls;

public class MainCls {

	public static void main(String[] args) {
		DeskConfig config = new DeskConfig();
		Desktops desk = (Desktops) config.retDesk();
		System.out.println(desk.toString());
	}

}
