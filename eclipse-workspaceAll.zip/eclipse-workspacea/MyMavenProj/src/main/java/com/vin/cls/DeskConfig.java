package com.vin.cls;

public class DeskConfig {

	public Desktops retDesk() {
		Desktops ds = new Desktops(10, "Gateway Computers", "Brothers");
		return ds;
	}
}
