package com.vin.mrng;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class NumCls {
    public double retSqrt(int a) {
        return Math.sqrt(a);
    }

    public double retLog10(int a) {
        return Math.log10(a); // Corrected to return log base 10
    }

    public Double[] retArr() {
        return new Double[] { 1.0, 2.0, 3.0, 4.0, 5.0 }; // Included all elements
    }

    public Double[] retArray(int[] arr) {
        Double[] dArr = new Double[arr.length];
        for (int i = 0; i < arr.length; i++) {
            dArr[i] = arr[i] + 0.5;
        }
        return dArr;
    }

    public List<Integer> retList() {
        return Stream.iterate(1, a -> a + 1).limit(5).toList();
    }
    
    
    
    
}
