package com.vin.mrng;

/**
 * Utility Class to test some string functions
 * 
 * @return Vinay
 */
public class StrUtilsCls {
    /**
     * Return an input string in uppercase
     * 
     * @param i normal String
     * @return String in the Uppercase
     */
    public String retStrUp(String i) {
        return i.toUpperCase();
    }

    /**
     * Return an input string in lowercase
     * 
     * @param j normal String
     * @return String in the lowercase
     */
    public String retStrLo(String j) {
        return j.toLowerCase();
    }

    /**
     * Returns the reverse of input string
     * 
     * @param s input string
     * @return reverse of the string
     */
    public String retRev(String s) {
        return new StringBuffer(s).reverse().toString();
    }
}
