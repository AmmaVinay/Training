package com.vin.mrng;

public class MainCls {

	public static void main(String[] args) {

		StrUtilsCls a = new StrUtilsCls();
		System.out.println("UpperCase :" + 	a.retStrUp("Amma Vinay"));
		System.out.println("UpperCase :" + a.retStrLo("Amma Vinay"));

	}

}
