package com.vin.test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.vin.mrng.NumCls;

public class TestcaseNumCls {

    NumCls cls = null;

    @Before
    public void setUp() throws Exception {
        cls = new NumCls();
    }

    @After
    public void tearDown() throws Exception {
        cls = null;
    }

    @Test
    public void testRetSqrt() {
        double d = 2.0;
        assertEquals(d, cls.retSqrt(4), 0.0);
    }

    @Test
    public void testRetLog10() {
        double d = 1.0;
        assertEquals(d, cls.retLog10(10), 0.0);
    }

    @Test
    public void testRetArr() {
        Double[] arr = { 1.0, 2.0, 3.0, 4.0, 5.0 };
        assertArrayEquals(arr, cls.retArr());
    }

    @Test
    public void testRetArray() {
        Double[] arr = { 1.5, 2.5, 3.5, 4.5 };
        assertArrayEquals(arr, cls.retArray(new int[] { 1, 2, 3, 4 }));
    }

    @Test
    public void testRetList() {
        List<Integer> ll = Arrays.asList(1, 2, 3, 4, 5);
        assertArrayEquals(ll.toArray(), cls.retList().toArray());
    }
}
