package com.vin.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ClsUtilUp {
	ClsUtilUp cls = null;

	@Before
	public void setUp() throws Exception {
		cls = new ClsUtilUp();
	}

	@After
	public void tearDown() throws Exception {
		cls = null;
	}

	@Test
	public void testRetAltUp() {
		String testStr="SaTiS";
		String j=cls.retAltUp("Vinay");
		assertEquals(testStr , j);
 	}

}
