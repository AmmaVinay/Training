import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.vin.mrng.StrUtilsCls;

public class StrUtilsTestCase {

    StrUtilsCls cls = null;

    @Before
    public void setUp() throws Exception {
        cls = new StrUtilsCls();
    }

    @After
    public void tearDown() throws Exception {
        cls = null;
    }

    @Test
    public void testRetStrUp() {
        String y = "ABC";
        assertEquals(y, cls.retStrUp("abc"));
    }

    @Test
    public void testRetStrLo() {
        String y = "abc";
        assertEquals(y, cls.retStrLo("ABC"));
    }

    @Test
    public void testRetRev() {
        String y = "cba";
        assertEquals(y, cls.retRev("abc"));
    }
}
