package com.vin.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UtilsClsBTest {

    UtilClsB b = null;

    @BeforeEach
    void setUp() throws Exception {
        b = new UtilClsB();
    }

    @AfterEach
    void tearDown() throws Exception {
        b = null;
    }

    @Test
    void testRetSub() {
        String k = "sankara";
        assertEquals(k.substring(0, 3), b.retSub(k)); // Correct comparison
    }
}
