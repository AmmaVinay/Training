package com.vin.cls;

@FunctionalInterface
public interface IFaceBaseA {
	public String mySpeech();
}
