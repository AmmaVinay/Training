package com.vin.cls;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class McClsB {
	public static void main(String[] args) {
		Function<Integer, Double> sqrtFun = (a) -> Math.sqrt(a);
		System.out.println(sqrtFun.apply(10));

		Function<Integer, Double> sqrFun = (a) -> Math.pow(a, 2);
		System.out.println(sqrFun.apply(20));

		Function<String, String> retRev = (a) -> new StringBuffer(a).reverse().toString();
		System.out.println(retRev.apply("Amma Vinay"));

		BiFunction<Integer, Integer, Double> retHyp = (a, b) -> Math.hypot(a, b);
		System.out.println(retHyp.apply(5, 20));

		Function<Integer, Double> funa = (a) -> Math.pow(a, 2);
		Function<Double, Double> funb = (b) -> Math.sqrt(b);
		var fund = funa.andThen(funb);
		System.out.println(fund.apply(10));

		Function<Integer, Double> funA = (a) -> Math.pow(a, 2);
		Function<Double, Double> funB = (b) -> Math.log10(b);
		var funD = funA.andThen(funB);
		System.out.println(funD.apply(10));

		Predicate<Integer> apred = (a) -> a > 10;
		int k = 100;
		System.out.println(apred.test(k));

		Predicate<String> bpred = (a) -> a.length() > 0;
		System.out.println(bpred.test("Vinay"));

		String arr[] = { "", "a", "ab", "abc", "abcd" };
		Arrays.asList(arr).stream().forEach(n -> System.out.print(bpred.test(n) ? "true " : ""));

		Predicate<Integer> cored = (a) -> a % 2 == 0;
		Integer arr1[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		Arrays.asList(arr).stream().forEach(n -> System.out.print(bpred.test(n) ? "true " : ""));

		List<String> lsa = new ArrayList<>(Arrays.asList("Vinay", "Pavan", "Krishna", "Chakri"));
		List<String> lsb = new ArrayList<>(Arrays.asList("Vishal", "Ankitha"));
		BiConsumer<List<String>, List<String>> dispLists = (lista, listb) -> {
			lista.stream().forEach(n -> System.out.println(n.toUpperCase()));
			System.out.println("*".repeat(50));
			listb.stream().forEach(n -> System.out.println(n.toUpperCase()));
		};
		dispLists.accept(lsa, lsb);

		BiConsumer<List<Integer>, Set<Integer>> aConsumer = (list1, set2) -> {
			Set<Integer> set3 = list1.stream().collect(Collectors.toSet());
			Iterator<Integer> itra = set3.iterator();
			Iterator<Integer> itrb = set2.iterator();
			while (itra.hasNext()) {
				System.out.println(itra.next());
			}
			System.out.println("*".repeat(50));
			while (itrb.hasNext()) {
				System.out.println(itrb.next());
			}
		};
		List<Integer> laa = new ArrayList<>();
		laa = Arrays.asList(21, 21, 21, 21, 21, 23, 24, 25, 26, 2728, 98, 98, 98);
		Set<Integer> setaa = new HashSet<>();
		Arrays.asList(32, 32, 32, 32, 32, 54, 54, 65, 76, 87, 99).forEach(n -> setaa.add(n));
		aConsumer.accept(laa, setaa);
		System.out.println("***********************");
		varyingArhgs(12, 34, 5, 66, 778, 23);

	}

	public static void varyingArhgs(Integer... a) {
		Arrays.asList(a).forEach(System.out::println);
	}

}