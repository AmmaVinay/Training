package com.vin.cls;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MyClsC {
	public static void main(String[] args) {
		Stream.iterate(1, e -> e + 1).filter(a -> a % 2 == 0).limit(20).forEach(System.out::println);
		var aList = Stream.iterate(1, a -> a + 1).filter(a -> a % 2 != 0).limit(20).collect(Collectors.toList());
		aList.forEach(System.out::println);

		Integer arr1[] = { 54, 65, 76, 87 };
		String[] arr2 = { "Vinay", "Pavan", "Krishna", "Chakri" };
		int k = 0;
		List<Cubicle> lsc = new ArrayList<>();
		for (Integer a : arr1) {
			lsc.add(new Cubicle(a, arr2[k]));
			k++;
		}
		var aa = lsc.stream().map(n -> n.getDim()).collect(Collectors.toList());
		aa.parallelStream().forEach(System.out::println);

	}
}
