package com.vin.cls;

import java.util.ArrayList;
import java.util.List;

public class MyClsA {
	static String saySomething() {
		return "This is method";
	}

	public static void main(String[] args) {
		Integer[] in = { 11, 22, 23, 24, 25 };
		String[] st = { "abc", "def", "ghi" };
		List<Cubicle> lc = new ArrayList<Cubicle>();
		for (int i = 0; i < st.length; i++) {
			Cubicle c = new Cubicle(in[i], st[i]);
			lc.add(c);
		}
		lc.stream().forEach(n -> System.out.println(n.getDim()+" "+n.getName()));

		// Method reference
//		IFaceBaseA bas=MyClsA::saySomething;
//		System.out.println(bas.mySpeech());
//		Integer[] arr = {1,2,3,4,5,6,7,8,9,10};
//		Arrays.asList(arr).stream().forEach(n -> System.out.println(n));	
//		String[] arr2 = {"abc","def", "ghi"};
//		Arrays.asList(arr2).stream().forEach(n->System.out.println(n));
//		Boolean[] arr3 = {true, false, true, true};
//		Arrays.asList(arr3).stream().forEach(n->System.out.println(n?"True":"False"));
//		Character[] ch = {'a','b','c','d'};
//		Arrays.asList(ch).stream().forEach(n->System.out.println(n));

	}
}
