package com.vin.cls;

public class Cubicle {
	private int dim;
	private String name;

	public Cubicle(int dim, String name) {
		super();
		this.dim = dim;
		this.name = name;
	}

	public int getDim() {
		return dim;
	}

	public void setDim(int dim) {
		this.dim = dim;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
