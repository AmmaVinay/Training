package co.springcoders;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyService {
	@GetMapping("/first")
	public String tester() {
		return "This is final string";
	}
}
