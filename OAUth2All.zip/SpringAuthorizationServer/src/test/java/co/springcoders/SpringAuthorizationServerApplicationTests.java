package co.springcoders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAuthorizationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
