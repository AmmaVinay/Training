package com.springcoders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OAuthResourceServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(OAuthResourceServerApplication.class, args);
	}

}
