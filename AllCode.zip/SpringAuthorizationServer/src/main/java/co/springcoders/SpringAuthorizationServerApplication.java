package co.springcoders;

import java.security.KeyPair;
import java.security.KeyPairGenerator;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringAuthorizationServerApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringAuthorizationServerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
	}

}
